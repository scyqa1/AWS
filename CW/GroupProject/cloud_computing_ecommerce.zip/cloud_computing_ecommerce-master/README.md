# cloud_computing_ecommerce

### Usage
```
python3 manage.py runserver
```
### Features
- Index page: localhost:8000/ecommerce/
- Login: localhost:8000/ecommerce/login
- Sign up: localhost:8000/ecommerce/signup
- Orders: localhost:8000/ecommerce/orders