SELECT COUNT(*) FROM Product where is_on_sale = TRUE;
