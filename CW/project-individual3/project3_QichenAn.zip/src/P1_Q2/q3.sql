SELECT * FROM Customer WHERE customer_name = "Bob";
