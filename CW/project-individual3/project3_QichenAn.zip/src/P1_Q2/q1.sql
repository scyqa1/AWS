SELECT * FROM Orders;
