SELECT * FROM Orders ORDER BY total_price DESC LIMIT 3;
